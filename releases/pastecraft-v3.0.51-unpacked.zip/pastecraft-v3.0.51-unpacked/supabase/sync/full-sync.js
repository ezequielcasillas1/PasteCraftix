/** Vertical slice: full-sync.js */
import { assertWorkspaceOwnerForSync } from '../../bridges/workspace/workspace.facade.js';
import { mergeUserProfileLocalRemote } from '../../shared/profile-merge.js';

export const fullSyncMixin = {
// FULL SYNC METHOD (Call on startup)
// =====================================================

/**
 * Perform full bidirectional sync on extension startup
 */
async performFullSync() {
  if (!this.client) {
    console.warn('⚠️ Supabase not initialized - skipping full sync');
    return {
      success: false,
      message: 'Supabase not configured'
    };
  }
  if (this._fullSyncPromise) {
    return await this._fullSyncPromise;
  }

  this._isFullSyncRunning = true;
  this._fullSyncPromise = (async () => {
    try {
    if (!(await this.hasActiveAuthSession())) {
      console.warn('⚠️ Skipping full sync: no active Supabase session (sign in again)');
      return {
        success: false,
        message: 'Not authenticated'
      };
    }

    const userId = await this.getSyncUserId();

    // Hard account isolation: never merge/upload when local owner ≠ session user.
    const ownerGate = await assertWorkspaceOwnerForSync(userId);
    if (!ownerGate.ok) {
      console.warn('⚠️ Skipping full sync: workspace owner gate failed', ownerGate.reason);
      return {
        success: false,
        message: 'Workspace owner mismatch'
      };
    }
    if (ownerGate.cleared) {
      console.info('🔒 Local library cleared for account bind; hydrating from cloud only');
    }
    
    // Check cloud sync access (FREE tier = local only)
    const hasAccess = await this.hasCloudSyncAccess(userId);
    if (!hasAccess) {
      console.log('ℹ️ Cloud sync not available for free tier. Using local storage only.');
      return {
        success: false,
        message: 'Cloud sync requires Basic or Enhanced subscription'
      };
    }
    
    console.log('🔄 Starting full bidirectional sync...');

    // Get local data from Chrome storage (empty after owner clear → cloud-only hydrate)
    const localData = await new Promise((resolve) => {
      chrome.storage.local.get([
        'clips',
        'categories',
        'searchOnlyClips',
        'notes',
        'autoDeletePeriod',
        'quickPasteSettings',
        'albumAttachmentOpenMode',
        'theme',
        'settingsUpdatedAt',
        'userProfile',
        'pc_aiHistory_v1',
        'pc_deleted_clips',
        'pc_deleted_archived_clips',
        'pc_deleted_categories',
        'pc_deleted_notes',
        'pc_local_updatedAt'
      ], resolve);
    });

    const localClips = localData.clips || [];
    const localCategories = localData.categories || [];
    const localArchivedClips = localData.searchOnlyClips || [];
    const localNotes = localData.notes || [];
    const localProfile = localData.userProfile || {};
    const localSettingsUpdatedAt = typeof localData.settingsUpdatedAt === 'number' ? localData.settingsUpdatedAt : 0;
    const localAiHistory = localData.pc_aiHistory_v1 || [];
    const deletedClips = localData.pc_deleted_clips || [];
    const deletedArchivedClips = localData.pc_deleted_archived_clips || [];
    const deletedCategories = localData.pc_deleted_categories || [];
    const deletedNotes = localData.pc_deleted_notes || [];
    const snapshotLocalUpdatedAt = Number.isFinite(localData.pc_local_updatedAt) ? localData.pc_local_updatedAt : Date.now();
    const hasNewerLocalWrites = async () => {
      try {
        const latest = await chrome.storage.local.get(['pc_local_updatedAt']);
        const latestUpdatedAt = Number.isFinite(latest?.pc_local_updatedAt) ? latest.pc_local_updatedAt : 0;
        return latestUpdatedAt > snapshotLocalUpdatedAt;
      } catch (_) {
        return false;
      }
    };
    const pendingQueueCount = Array.isArray(this.syncQueue) ? this.syncQueue.length : 0;
    console.log(`📥 Startup sync running in read-mostly mode (${pendingQueueCount} queued local operation${pendingQueueCount === 1 ? '' : 's'})`);

    let localWritesApplied = false;

    // Read-mostly startup sync:
    // Local changes should travel through the queue/delta path. Re-uploading
    // whole local tables on every popup open is what has been timing out.
    const remoteClips = await this.syncClipsFromSupabase();
    if (remoteClips) {
      const mergedClips = await this.mergeClips(localClips, remoteClips);
      if (await hasNewerLocalWrites()) {
        console.warn('⏭️ Skipping clips merge write - newer local changes detected during full sync');
      } else {
        const clipsChanged = await this._safeStorageSet({ clips: mergedClips });
        localWritesApplied = localWritesApplied || clipsChanged;
        if (clipsChanged) {
          console.log(`✅ Clips merged: ${mergedClips.length} total`);
        }
      }
    }

    const remoteCategories = await this.syncCategoriesFromSupabase();
    if (remoteCategories) {
      const mergedCategories = await this.mergeCategories(localCategories, remoteCategories);
      if (await hasNewerLocalWrites()) {
        console.warn('⏭️ Skipping categories merge write - newer local changes detected during full sync');
      } else {
        const categoriesChanged = await this._safeStorageSet({ categories: mergedCategories });
        localWritesApplied = localWritesApplied || categoriesChanged;
        if (categoriesChanged) {
          console.log(`✅ Categories merged: ${mergedCategories.length} total`);
        }
      }
    }

    const remoteArchivedClips = await this.syncArchivedClipsFromSupabase();
    if (remoteArchivedClips) {
      const mergedArchivedClips = await this.mergeArchivedClips(localArchivedClips, remoteArchivedClips);
      if (await hasNewerLocalWrites()) {
        console.warn('⏭️ Skipping archived clips merge write - newer local changes detected during full sync');
      } else {
        const archivedClipsChanged = await this._safeStorageSet({ searchOnlyClips: mergedArchivedClips });
        localWritesApplied = localWritesApplied || archivedClipsChanged;
        if (archivedClipsChanged) {
          console.log(`✅ Archived clips merged: ${mergedArchivedClips.length} total (limited to 1000 locally)`);
        }
      }
    }

    const remoteNotes = await this.syncNotesFromSupabase();
    if (remoteNotes) {
      const mergedNotes = await this.mergeNotes(localNotes, remoteNotes);
      if (await hasNewerLocalWrites()) {
        console.warn('⏭️ Skipping notes merge write - newer local changes detected during full sync');
      } else {
        const notesChanged = await this._safeStorageSet({ notes: mergedNotes });
        localWritesApplied = localWritesApplied || notesChanged;
        if (notesChanged) {
          console.log(`✅ Notes merged: ${mergedNotes.length} total`);
        }
      }
    }

    const remoteAiHistory = await this.fetchAiHistoryFromSupabase();
    if (remoteAiHistory && remoteAiHistory.length > 0) {
      const mergedAiHistory = this.mergeAiHistory(localAiHistory, remoteAiHistory);
      if (await hasNewerLocalWrites()) {
        console.warn('⏭️ Skipping AI history merge write - newer local changes detected during full sync');
      } else {
        const aiHistoryChanged = await this._safeStorageSet({ pc_aiHistory_v1: mergedAiHistory });
        localWritesApplied = localWritesApplied || aiHistoryChanged;
        if (aiHistoryChanged) {
          console.log(`✅ AI history merged: ${mergedAiHistory.length} total`);
        }
      }
    }

    const remoteSettings = await this.syncSettingsFromSupabase();
    if (remoteSettings) {
      let latestLocalSettingsUpdatedAt = localSettingsUpdatedAt;
      try {
        const latest = await chrome.storage.local.get(['settingsUpdatedAt']);
        latestLocalSettingsUpdatedAt = typeof latest?.settingsUpdatedAt === 'number' ? latest.settingsUpdatedAt : 0;
      } catch (_) {}

      const remoteSettingsUpdatedAt = typeof remoteSettings.settingsUpdatedAt === 'number'
        ? remoteSettings.settingsUpdatedAt
        : 0;
      if (latestLocalSettingsUpdatedAt > remoteSettingsUpdatedAt) {
        console.debug('⏭️ Keeping local settings (newer than cloud during full sync)');
      } else {
        const settingsPayload = this.toSettingsStoragePayload(remoteSettings);
        const settingsChanged = settingsPayload
          ? await this._safeStorageSet(settingsPayload)
          : false;
        localWritesApplied = localWritesApplied || settingsChanged;
        if (settingsChanged) {
          console.log('✅ Settings updated');
        }
      }
    }

    const remoteProfile = await this.syncUserProfileFromSupabase();
    if (remoteProfile) {
      if (await hasNewerLocalWrites()) {
        console.warn('⏭️ Skipping profile merge write - newer local changes detected during full sync');
      } else {
      const pickUrl = (localUrl, remoteUrl) => {
        const l = typeof localUrl === 'string' ? localUrl : '';
        const r = typeof remoteUrl === 'string' ? remoteUrl : '';
        if (!l && !r) return '';
        const supaHost = this._pcGetSupabaseHost();
        const isSupa = (x) => {
          const o = this._pcTryParseUrl(x);
          return !!(o && supaHost && o.hostname === supaHost);
        };
        const isTemp = (x) => {
          const o = this._pcTryParseUrl(x);
          if (!o) return false;
          const az = o.hostname.includes('blob.core.windows.net');
          const hasSig = o.searchParams.has('sig');
          return az || hasSig || this._pcIsExpiredSas(x);
        };
        if (isSupa(r)) return r;
        if (isSupa(l)) return l;
        if (l && isTemp(r)) return l;
        return r || l;
      };

      // Re-read local profile — snapshot may be stale if user saved during sync.
      let latestLocalProfile = localProfile;
      try {
        const latest = await chrome.storage.local.get(['userProfile']);
        if (latest?.userProfile && typeof latest.userProfile === 'object') {
          latestLocalProfile = latest.userProfile;
        }
      } catch (_) { /* keep snapshot */ }

      const mergedProfile = mergeUserProfileLocalRemote(latestLocalProfile, remoteProfile, pickUrl);
      const profileChanged = await this._safeStorageSet({ userProfile: mergedProfile });
      localWritesApplied = localWritesApplied || profileChanged;
      if (profileChanged) {
        console.log('✅ User profile updated');
      }
      }
    }

      console.log('✅ Full sync complete!');
      return {
        success: true,
        message: 'All data synced successfully',
        localWritesApplied,
        stats: {
          clips: remoteClips?.length || 0,
          categories: remoteCategories?.length || 0,
          archivedClips: remoteArchivedClips?.length || 0,
          notes: remoteNotes?.length || 0,
          aiHistory: remoteAiHistory?.length || 0
        }
      };

    } catch (error) {
      console.error('❌ Full sync failed:', error);
      return {
        success: false,
        message: error.message
      };
    } finally {
      this._isFullSyncRunning = false;
      this._fullSyncPromise = null;
      if (this.isOnline && this.syncQueue.length > 0 && !this._pauseSync) {
        Promise.resolve().then(() => this.processSyncQueue()).catch(() => {});
      }
    }
  })();

  return await this._fullSyncPromise;
}
};
