/** Vertical slice: ai-workflow.js */
export const aiWorkflowMixin = {
// AI WORKFLOW (provider + preset) - local-first read
// =====================================================

_normalizeAiWorkflow(raw) {
  const allowedProviders = new Set([
    'openai',
    'google',
    'anthropic',
    'deepseek',
    'alibaba',
    'inclusionai',
    'meta',
    'xai',
  ]);
  const presetsByProvider = {
    openai: new Set(['default', 'cheapest', 'gpt5_mini', 'latest', 'gpt4o']),
    google: new Set([
      'default',
      'cheapest',
      'gemini_pro',
      'latest',
      'gemini_37_flash',
      'gemini_38_flash',
      'gemini_35_flash_lite',
    ]),
    meta: new Set(['default', 'muse13']),
    anthropic: new Set(['default']),
    deepseek: new Set(['default', 'cheapest', 'deepseek_v41_flash']),
    alibaba: new Set(['default', 'qwen_flash']),
    inclusionai: new Set(['default', 'ling_flash']),
    xai: new Set(['default', 'grok47']),
  };

  const obj = (raw && typeof raw === 'object') ? raw : {};
  const enabled = obj.enabled === true;
  const presetAliases = {
    gemini_36_flash: 'gemini_38_flash',
    gemini_37_flash: 'gemini_38_flash',
    deepseek_v4_flash: 'deepseek_v41_flash',
  };
  let provider = allowedProviders.has(String(obj.provider || 'openai')) ? String(obj.provider || 'openai') : 'openai';
  let storedPreset = presetAliases[String(obj.preset || '')] || String(obj.preset || 'default');
  if (provider === 'openai' && storedPreset === 'gpt4o') {
    provider = 'meta';
    storedPreset = 'muse13';
  }
  if (provider === 'openai' && storedPreset === 'gpt54') {
    provider = 'xai';
    storedPreset = 'grok47';
  }
  const allowedPresets = presetsByProvider[provider] || presetsByProvider.openai;
  const preset = allowedPresets.has(storedPreset) ? storedPreset : 'default';
  const updatedAt = Number.isFinite(Number(obj.updatedAt)) ? Number(obj.updatedAt) : 0;
  return { enabled, provider, preset, updatedAt };
},

  async getAiWorkflowConfig() {
  // Cache for a few seconds to avoid storage overhead on rapid calls.
  try {
    const now = Date.now();
    if (this._aiWorkflowCache && (now - (this._aiWorkflowCache.at || 0)) < 5000) {
      return this._aiWorkflowCache.value;
    }

    const key = this._aiWorkflowKey;
    let local = null;
    try {
      local = await chrome.storage.local.get([key]);
    } catch (_) {
      local = null;
    }

    let cfg = this._normalizeAiWorkflow(local ? local[key] : null);
    if (!cfg.enabled) {
      // Fall back to sync only if local is missing/disabled (best-effort)
      try {
        const sync = await new Promise((resolve) => chrome.storage.sync.get([key], resolve));
        const fromSync = this._normalizeAiWorkflow(sync ? sync[key] : null);
        if (fromSync.enabled && fromSync.updatedAt >= cfg.updatedAt) cfg = fromSync;
      } catch (_) {}
    }

    const finalCfg = cfg && cfg.enabled ? { enabled: true, provider: cfg.provider, preset: cfg.preset, updatedAt: cfg.updatedAt } : null;
    this._aiWorkflowCache = { value: finalCfg, at: now };
    return finalCfg;
  } catch (_) {
    return null;
  }
},

/**
 * Directly set the in-memory AI workflow cache (bypasses storage read).
 * Call this after saving workflow from the UI so the next AI call
 * immediately reflects the user's selection.
 */
  setAiWorkflowConfigDirect(cfg) {
  if (!cfg || typeof cfg !== 'object') {
    this._aiWorkflowCache = { value: null, at: 0 };
    return;
  }
  const normalized = this._normalizeAiWorkflow(cfg);
  const finalCfg = normalized.enabled
    ? { enabled: true, provider: normalized.provider, preset: normalized.preset, updatedAt: normalized.updatedAt }
    : null;
  this._aiWorkflowCache = { value: finalCfg, at: Date.now() };
},

  async _withAiWorkflow(body) {
  try {
    const base = (body && typeof body === 'object') ? body : {};
    const cfg = await this.getAiWorkflowConfig();
    if (!cfg) return base;
    return { ...base, aiWorkflow: cfg };
  } catch (_) {
    return body;
  }
}

// =====================================================
};
